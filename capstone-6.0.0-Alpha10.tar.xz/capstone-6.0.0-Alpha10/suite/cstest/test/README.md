Integration tests of cstest
