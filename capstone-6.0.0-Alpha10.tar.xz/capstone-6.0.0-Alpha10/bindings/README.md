This directory contains bindings & test code for Python, Java & OCaml.
See `<language>/README.md` for how to compile & install each binding.

More bindings created & maintained by the community are available as followings.

- Gapstone: Go binding (by Scott Knight).

	https://github.com/knightsc/gapstone

- Crabstone: Ruby binding for Capstone 3+ (by david942j).

	https://github.com/david942j/crabstone

- Crabstone: Ruby binding (by Ben Nagy).

	https://github.com/bnagy/crabstone

- Capstone-Vala: Vala binding (by Pancake).

	https://github.com/radare/capstone-vala

- Node-Capstone: NodeJS binding (by Jason Oster).

	https://github.com/parasyte/node-capstone

- CCcapstone: C++ binding (by Peter Hlavaty).

	https://github.com/zer0mem/cccapstone

- LuaCapstone: Lua binding (by Antonio Davide).

	https://github.com/Dax89/LuaCapstone

- Capstone-RS: Rust binding (by Richo Healey).

	https://github.com/capstone-rust/capstone-rs

- Capstone.NET: .NET framework binding (by Ahmed Garhy).

	https://github.com/9ee1/Capstone.NET

- CapstoneJ: High level Java wrapper for Capstone-java (by Keve Müller).

	https://github.com/kevemueller/capstonej

- Hapstone: Haskell binding (by ibabushkin)

    https://github.com/ibabushkin/hapstone

- CL-Capstone: Common Lisp bindings (by GrammaTech).

    https://github.com/GrammaTech/cl-capstone

- Emacs-capstone: Emacs (elisp) binding (by Bas Alberts)

    https://github.com/collarchoke/emacs-capstone

- C# binding (by Matt Graeber). Note: this is only for Capstone v2.0.

	https://github.com/mattifestation/capstone

- PowerShell binding (by Ruben Boonen).

	https://github.com/aquynh/capstone/tree/master/bindings/powershell

- PHP binding (by Fadhil Mandaga).

	https://github.com/firodj/php-capstone
	
- capstone-d: D binding (by Dimitri Bohlender)

	https://github.com/bohlender/capstone-d

- Swift binding (by Jesús A. Álvarez)

	https://github.com/zydeco/capstone-swift
